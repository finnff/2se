#pragma once

enum states
{
    empty,
    noughts,
    crosses
}; // 0 empty, 1 = noughts, 2 = crosses
